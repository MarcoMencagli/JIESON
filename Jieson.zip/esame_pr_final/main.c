#include <stdio.h>
#include "gamelib.h"

int main (){
int scelta;

		do{
      	printf("\t\t __________________________________________________________________________ \n");
      	printf("\t\t|                                                                          |\n");
      	printf("\t\t|                     F R I D A Y   T H E    13 TH                         |\n");
      	printf("\t\t|                        T  H  E       G  A  M  E.                         |\n");
      	printf("\t\t|                                                                          |\n");
        printf("\t\t|                           1 --> Crea Mappa                               |\n");
        printf("\t\t|                           2 --> Gioca                                    |\n");
        printf("\t\t|                           3 --> Termina Gioco                            |\n");
        printf("\t\t|                                                                          |\n");
      	printf("\t\t|__________________________________________________________________________|\n");
        printf("\n");
        printf("--> SCEGLI UNA DELLE SEGUENTE AZIONI\n");
			scanf("%d", &scelta);

		switch(scelta){
				case 1:
					printf("AZIONE SELEZIONATA --> CREA MAPPA\n");
					crea_mappa();
					break;
				case 2:
					printf("AZIONE SELEZIONATA --> GIOCA\n");
					gioca();
					break;
				case 3:
					printf("AZIONE SELEZIONATA --> TERMINA GIOCO\n");
					termina_gioco();
					break;
				default:
					printf("ATTENZIONE --> VALORE INSERITO NON VALIDO\n");
					break;
				}
		}while(scelta!=3);
	}
